#ifndef __DIA_EN_LA_UNI_H__
#define __DIA_EN_LA_UNI_H__

//Pre_condicion: -
//Post_codicion: Devuelve un determinado personaje segun las preguntas contestadas.
void seleccionar_personaje(char *personaje_tp1);

#endif //__DISNEY_H__